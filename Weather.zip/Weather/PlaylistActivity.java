package com.example.musicplayer;
import com.example.myapplication.R;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PlaylistActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SongsAdapter songsAdapter;
    private ArrayList<Song> songList;
    private MediaPlayer mediaPlayer;
    private SeekBar seekBar;
    private TextView textViewTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        recyclerView = findViewById(R.id.recyclerViewSongs);
        seekBar = findViewById(R.id.seekBar);
        textViewTimer = findViewById(R.id.textViewTimer);

        songList = new ArrayList<>();
        songList.add(new Song("Song 1", "Artist 1", "https://example.com/song1.mp3"));
        songList.add(new Song("Song 2", "Artist 2", "https://example.com/song2.mp3"));
        songList.add(new Song("Song 3", "Artist 3", "https://example.com/song3.mp3"));

        songsAdapter = new SongsAdapter(songList, new SongsAdapter.OnSongClickListener() {
            @Override
            public void onPlayClick(Song song) {
                playSong(song);
            }

            @Override
            public void onPauseClick() {
                pauseSong();
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(songsAdapter);
    }

    private void playSong(Song song) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(song.getUrl());
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void pauseSong() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    @Override
    protected void onDestroy() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        super.onDestroy();
    }
}
